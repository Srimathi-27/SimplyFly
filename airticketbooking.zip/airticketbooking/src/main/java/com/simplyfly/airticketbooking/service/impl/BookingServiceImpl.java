package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.BookingRequest;
import com.simplyfly.airticketbooking.dto.BookingResponse;
import com.simplyfly.airticketbooking.entity.*;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.*;
import com.simplyfly.airticketbooking.service.BookingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j // logging
@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final SeatRepository seatRepository;
    private final UserRepository userRepository;
    private final FlightRepository flightRepository;

    @Override
    public BookingResponse bookFlight(BookingRequest request, Authentication authentication) {
        String userEmail = authentication.getName();
        log.info("Starting booking for user: {}", userEmail);

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Flight flight = flightRepository.findById(request.getFlightId())
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));

        log.info("Flight selected: {} (ID: {})", flight.getFlightName(), flight.getId());

        List<Seat> availableSeats = seatRepository.findByFlightAndIsBookedFalse(flight);

        if (availableSeats.size() < request.getSeatCount()) {
            log.warn("Not enough seats. Requested: {}, Available: {}", request.getSeatCount(), availableSeats.size());
            throw new RuntimeException("Not enough seats available");
        }

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setFlight(flight);
        booking.setBookingDate(LocalDateTime.now());
        booking.setSeatCount(request.getSeatCount());
        booking.setTotalPrice(flight.getFare() * request.getSeatCount());
        booking.setStatus("BOOKED");
        Booking savedBooking = bookingRepository.save(booking);

        List<Seat> seatsToBook = availableSeats.subList(0, request.getSeatCount());
        for (Seat seat : seatsToBook) {
            seat.setBooked(true);
            seat.setBooking(savedBooking);
        }
        seatRepository.saveAll(seatsToBook);

        log.info("Booking successful. Booking ID: {}", savedBooking.getId());

        return new BookingResponse(
                savedBooking.getId(),
                flight.getFlightNumber(),
                flight.getFlightName(),
                flight.getRoute().getOrigin(),
                flight.getRoute().getDestination(),
                savedBooking.getSeatCount(),
                savedBooking.getTotalPrice(),
                savedBooking.getStatus(),
                savedBooking.getBookingDate()
        );
    }

    @Override
    public List<BookingResponse> getMyBookings(Authentication authentication) {
        String userEmail = authentication.getName();
        log.info("Retrieving bookings for user: {}", userEmail);

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        List<Booking> bookings = bookingRepository.findByUser(user);

        return bookings.stream()
                .map(booking -> {
                    Flight flight = booking.getFlight();
                    return new BookingResponse(
                            booking.getId(),
                            flight.getFlightNumber(),
                            flight.getFlightName(),
                            flight.getRoute().getOrigin(),
                            flight.getRoute().getDestination(),
                            booking.getSeatCount(),
                            booking.getTotalPrice(),
                            booking.getStatus(),
                            booking.getBookingDate()
                    );
                })
                .collect(Collectors.toList());
    }

    @Override
    public String cancelBooking(Long bookingId, Authentication authentication) {
        String userEmail = authentication.getName();
        log.info("Attempting to cancel booking ID: {} by user: {}", bookingId, userEmail);

        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        if (!booking.getUser().getId().equals(user.getId())) {
            log.error("Unauthorized cancellation attempt by user: {}", userEmail);
            throw new RuntimeException("You are not allowed to cancel this booking");
        }

        if (!"BOOKED".equals(booking.getStatus())) {
            log.warn("Attempt to cancel booking with status: {}", booking.getStatus());
            throw new RuntimeException("Only booked tickets can be cancelled");
        }

        booking.setStatus("CANCELLED");
        bookingRepository.save(booking);

        List<Seat> seats = seatRepository.findByBookingId(bookingId);
        for (Seat seat : seats) {
            seat.setBooked(false);
            seat.setBooking(null);
        }
        seatRepository.saveAll(seats);

        log.info("Booking ID: {} cancelled and seats released.", bookingId);
        return "Booking cancelled successfully.";
    }

    @Override
    public List<BookingResponse> getAllBookings() {
        log.info("Admin request: retrieving all bookings in system");

        List<Booking> bookings = bookingRepository.findAll();

        return bookings.stream()
                .map(booking -> {
                    Flight flight = booking.getFlight();
                    return new BookingResponse(
                            booking.getId(),
                            flight.getFlightNumber(),
                            flight.getFlightName(),
                            flight.getRoute().getOrigin(),
                            flight.getRoute().getDestination(),
                            booking.getSeatCount(),
                            booking.getTotalPrice(),
                            booking.getStatus(),
                            booking.getBookingDate()
                    );
                }).collect(Collectors.toList());
    }
}
