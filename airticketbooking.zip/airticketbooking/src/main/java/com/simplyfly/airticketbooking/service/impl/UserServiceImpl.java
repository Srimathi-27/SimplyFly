package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.AuthResponse;
import com.simplyfly.airticketbooking.dto.LoginRequest;
import com.simplyfly.airticketbooking.dto.RegisterRequest;
import com.simplyfly.airticketbooking.entity.User;
import com.simplyfly.airticketbooking.enums.Role;
import com.simplyfly.airticketbooking.repository.UserRepository;
import com.simplyfly.airticketbooking.security.JwtTokenUtil;
import com.simplyfly.airticketbooking.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenUtil jwtTokenUtil;
    private final AuthenticationManager authenticationManager;

    // 🔐 Register
    @Override
    public AuthResponse registerUser(RegisterRequest request) {
        log.info("Attempting to register user with email: {}", request.getEmail());

        if (userRepository.existsByEmail(request.getEmail())) {
            log.warn("Registration failed - email already in use: {}", request.getEmail());
            throw new RuntimeException("Email already in use");
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setContactNumber(request.getContactNumber());
        user.setAddress(request.getAddress());
        user.setRole(request.getRole() != null ? request.getRole() : Role.USER);

        userRepository.save(user);
        //log.info("User registered successfully: {}", request.getEmail());

        String token = jwtTokenUtil.generateToken(user.getEmail(), user.getRole().name());

        return new AuthResponse(token, user.getRole().name(), "User registered successfully");
    }

    // 🔐 Login
    @Override
    public AuthResponse authenticateUser(LoginRequest request) {
        log.info("Login attempt for email: {}", request.getEmail());

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    log.error("User not found during login: {}", request.getEmail());
                    return new RuntimeException("User not found");
                });

        log.info("Login successful for user: {}", request.getEmail());
        String token = jwtTokenUtil.generateToken(user.getEmail(), user.getRole().name());

        return new AuthResponse(token, user.getRole().name(), "Login successful");
    }

    // 👤 User profile
    @Override
    public User getCurrentUser(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public User updateCurrentUser(String email, User updatedUser) {
        User user = getCurrentUser(email);
        user.setName(updatedUser.getName());
        user.setAddress(updatedUser.getAddress());
        user.setContactNumber(updatedUser.getContactNumber());
        return userRepository.save(user);
    }

    // 🛠️ Admin methods
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    @Override
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
