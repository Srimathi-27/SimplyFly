package com.simplyfly.airticketbooking.controller;

import com.simplyfly.airticketbooking.dto.AddFlightRequest;
import com.simplyfly.airticketbooking.dto.FlightResponse;
import com.simplyfly.airticketbooking.dto.FlightSearchRequest;
import com.simplyfly.airticketbooking.service.FlightService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/flights")
@RequiredArgsConstructor
public class FlightController {

    private final FlightService flightService;

    // 🔹 GET all flights (for users)
    @GetMapping
    public ResponseEntity<List<FlightResponse>> getAllFlights() {
        log.info("GET /api/flights called");
        List<FlightResponse> flights = flightService.getAllFlights();
        return ResponseEntity.ok(flights);
    }

    // 🔹 GET flight by ID (for confirmation or detail page)
    @GetMapping("/{id}")
    public ResponseEntity<FlightResponse> getFlightById(@PathVariable Long id) {
        log.info("GET /api/flights/{} called", id);
        FlightResponse response = flightService.getFlightById(id);
        return ResponseEntity.ok(response);
    }

    // 🔹 POST create a flight (Admin or Flight Owner)
    @PostMapping
    @PreAuthorize("hasAnyAuthority('ADMIN', 'FLIGHT_OWNER')")
    public ResponseEntity<String> addFlight(@RequestBody AddFlightRequest request,
                                            Authentication authentication) {
        log.info("POST /api/flights called by {}", authentication.getName());
        flightService.addFlight(request, authentication);
        return ResponseEntity.ok("Flight added successfully");
    }

    // 🔹 PUT update a flight (Admin or Owner only)
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN', 'FLIGHT_OWNER')")
    public ResponseEntity<String> updateFlight(@PathVariable Long id,
                                               @RequestBody AddFlightRequest request,
                                               Authentication authentication) {
        log.info("PUT /api/flights/{} called by {}", id, authentication.getName());
        flightService.updateFlight(id, request, authentication);
        return ResponseEntity.ok("Flight updated successfully");
    }

    // 🔹 DELETE a flight (Admin or Owner)
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('ADMIN', 'FLIGHT_OWNER')")
    public ResponseEntity<String> deleteFlight(@PathVariable Long id) {
        log.info("DELETE /api/flights/{} called", id);
        flightService.deleteFlight(id);
        return ResponseEntity.ok("Flight deleted successfully");
    }

    // 🔹 POST search flights
    @PostMapping("/search")
    public ResponseEntity<List<FlightResponse>> searchFlights(@RequestBody FlightSearchRequest request) {
        log.info("POST /api/flights/search called");
        List<FlightResponse> flights = flightService.searchFlights(request);
        return ResponseEntity.ok(flights);
    }
}

