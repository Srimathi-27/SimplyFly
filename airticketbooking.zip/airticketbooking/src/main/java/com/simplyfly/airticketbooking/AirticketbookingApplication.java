package com.simplyfly.airticketbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirticketbookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirticketbookingApplication.class, args);
		System.out.println("SIMPLY FLY.......!");
	}

}
