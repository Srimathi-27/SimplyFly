package com.simplyfly.airticketbooking.controller;

import com.simplyfly.airticketbooking.dto.AuthResponse;
import com.simplyfly.airticketbooking.dto.LoginRequest;
import com.simplyfly.airticketbooking.dto.RegisterRequest;
import com.simplyfly.airticketbooking.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@RequestBody RegisterRequest request) {
        log.info("POST /api/auth/register called for email: {}", request.getEmail());
        AuthResponse response = userService.registerUser(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
        log.info("POST /api/auth/login called for email: {}", request.getEmail());
        AuthResponse response = userService.authenticateUser(request);
        return ResponseEntity.ok(response);
    }
}
