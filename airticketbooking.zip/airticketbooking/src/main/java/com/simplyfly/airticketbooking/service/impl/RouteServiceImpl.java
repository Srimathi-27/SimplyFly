package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.AddRouteRequest;
import com.simplyfly.airticketbooking.entity.Route;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.RouteRepository;
import com.simplyfly.airticketbooking.service.RouteService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class RouteServiceImpl implements RouteService {

    private final RouteRepository routeRepository;

    @Override
    public void addRoute(AddRouteRequest request) {
        log.info("Attempting to add route: {} -> {}", request.getOrigin(), request.getDestination());

        boolean exists = routeRepository.existsByOriginAndDestination(
                request.getOrigin(), request.getDestination()
        );

        if (exists) {
            log.warn("Route already exists: {} -> {}", request.getOrigin(), request.getDestination());
            throw new RuntimeException("Route already exists.");
        }

        Route route = new Route(
                null,
                request.getOrigin(),
                request.getDestination(),
                request.getDistanceInKm(),
                request.getDuration()
        );

        routeRepository.save(route);
        log.info("Route successfully added: {} -> {}", request.getOrigin(), request.getDestination());
    }
    @Override
    public List<AddRouteRequest> getAllRoutes() {
        return routeRepository.findAll().stream().map(route ->
                new AddRouteRequest(
                        route.getOrigin(),
                        route.getDestination(),
                        route.getDistanceInKm(),
                        route.getDuration()
                )).collect(Collectors.toList());
    }

    @Override
    public void updateRoute(Long id, AddRouteRequest request) {
        Route route = routeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Route not found"));

        route.setOrigin(request.getOrigin());
        route.setDestination(request.getDestination());
        route.setDistanceInKm(request.getDistanceInKm());
        route.setDuration(request.getDuration());

        routeRepository.save(route);
        log.info("Route with ID {} updated successfully", id);
    }
}