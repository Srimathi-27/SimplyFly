package com.simplyfly.airticketbooking.service;

import com.simplyfly.airticketbooking.dto.AuthResponse;
import com.simplyfly.airticketbooking.dto.LoginRequest;
import com.simplyfly.airticketbooking.dto.RegisterRequest;
import com.simplyfly.airticketbooking.entity.User;

import java.util.List;

public interface UserService {

    // 🔐 Auth
    AuthResponse registerUser(RegisterRequest request);
    AuthResponse authenticateUser(LoginRequest request);

    // 👤 User management
    User getCurrentUser(String email);
    User updateCurrentUser(String email, User updatedUser);

    // 🛠️ Admin management
    List<User> getAllUsers();
    User getUserById(Long id);
    void deleteUser(Long id);
}
