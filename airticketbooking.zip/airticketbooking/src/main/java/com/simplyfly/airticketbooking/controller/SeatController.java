package com.simplyfly.airticketbooking.controller;

import com.simplyfly.airticketbooking.dto.SeatDTO;
import com.simplyfly.airticketbooking.entity.Flight;
import com.simplyfly.airticketbooking.entity.Seat;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.FlightRepository;
import com.simplyfly.airticketbooking.repository.SeatRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/seats")
@RequiredArgsConstructor
public class SeatController {

    private final SeatRepository seatRepository;
    private final FlightRepository flightRepository;
    // 🔍 View seats by Flight ID
    @GetMapping("/flight/{flightId}")
    @PreAuthorize("hasAuthority('ADMIN')")
    
    public ResponseEntity<List<SeatDTO>> getSeatsByFlight(@PathVariable Long flightId) {
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));

        List<SeatDTO> seatDTOs = seatRepository.findByFlightAndIsBookedFalse(flight).stream()
                .map(seat -> new SeatDTO(
                        seat.getId(),
                        seat.getSeatNumber(),
                        seat.isBooked()
                )).collect(Collectors.toList());

        return ResponseEntity.ok(seatDTOs);
    }
    
}

