package com.simplyfly.airticketbooking.controller;

import com.simplyfly.airticketbooking.entity.User;
import com.simplyfly.airticketbooking.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    // Admin: View all users
    @GetMapping
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<List<User>> getAllUsers() {
        log.info("GET /api/users - admin view all");
        return ResponseEntity.ok(userService.getAllUsers());
    }

    // Admin: Get user by ID
    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        log.info("GET /api/users/{} - admin fetch user", id);
        return ResponseEntity.ok(userService.getUserById(id));
    }

    // Admin: Delete user
    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        log.info("DELETE /api/users/{} - admin delete user", id);
        userService.deleteUser(id);
        return ResponseEntity.ok("User deleted successfully");
    }

    // User: View own profile
    @GetMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<User> getCurrentUser(Authentication authentication) {
        String email = authentication.getName();
        log.info("GET /api/users/me - user: {}", email);
        return ResponseEntity.ok(userService.getCurrentUser(email));
    }

    // User: Update own profile
    @PutMapping("/me")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<User> updateCurrentUser(@Valid @RequestBody User updatedUser,
                                                  Authentication authentication) {
        String email = authentication.getName();
        log.info("PUT /api/users/me - updating user: {}", email);
        return ResponseEntity.ok(userService.updateCurrentUser(email, updatedUser));
    }
}
