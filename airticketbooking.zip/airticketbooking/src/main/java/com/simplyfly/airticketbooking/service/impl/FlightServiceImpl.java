package com.simplyfly.airticketbooking.service.impl;

import com.simplyfly.airticketbooking.dto.AddFlightRequest;
import com.simplyfly.airticketbooking.dto.FlightResponse;
import com.simplyfly.airticketbooking.dto.FlightSearchRequest;
import com.simplyfly.airticketbooking.entity.Flight;
import com.simplyfly.airticketbooking.entity.Route;
import com.simplyfly.airticketbooking.entity.Seat;
import com.simplyfly.airticketbooking.entity.User;
import com.simplyfly.airticketbooking.exception.ResourceNotFoundException;
import com.simplyfly.airticketbooking.repository.FlightRepository;
import com.simplyfly.airticketbooking.repository.RouteRepository;
import com.simplyfly.airticketbooking.repository.UserRepository;
import com.simplyfly.airticketbooking.service.FlightService;
import com.simplyfly.airticketbooking.repository.SeatRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class FlightServiceImpl implements FlightService {

    private final FlightRepository flightRepository;
    private final RouteRepository routeRepository;
    private final UserRepository userRepository;
    private final SeatRepository seatRepository;

    @Override
    public void addFlight(AddFlightRequest request, Authentication authentication) {
        log.info("Attempting to add flight: {} by user: {}", request.getFlightNumber(), authentication.getName());

        Route route = routeRepository.findById(request.getRouteId())
                .orElseThrow(() -> {
                    log.error("Route not found for ID: {}", request.getRouteId());
                    return new RuntimeException("Route not found");
                });

        String userEmail = authentication.getName();
        User owner = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> {
                    log.error("User not found with email: {}", userEmail);
                    return new RuntimeException("User not found");
                });

        Flight flight = new Flight();
        flight.setFlightNumber(request.getFlightNumber());
        flight.setFlightName(request.getFlightName());
        flight.setRoute(route);
        flight.setTotalSeats(request.getTotalSeats());
        flight.setFare(request.getFare());
        flight.setBaggageCheckin(request.getBaggageCheckin());
        flight.setBaggageCabin(request.getBaggageCabin());
        flight.setDepartureTime(request.getDepartureTime());
        flight.setArrivalTime(request.getArrivalTime());
        flight.setFlightOwner(owner);

        Flight savedFlight = flightRepository.save(flight);

     // ✅ Generate seats for the flight
     List<Seat> seats = new ArrayList<>();
     for (int i = 1; i <= request.getTotalSeats(); i++) {
         Seat seat = new Seat();
         seat.setSeatNumber("S" + i);
         seat.setStatus("AVAILABLE");
         seat.setBooked(false);
         seat.setFlight(savedFlight);
         seats.add(seat);
     }
     seatRepository.saveAll(seats);

     log.info("Flight added successfully with {} seats", seats.size());
     log.info("Flight added successfully: {} (ID: {})", savedFlight.getFlightName(), savedFlight.getId());
    }

    @Override
    public List<FlightResponse> getAllFlights() {
        log.info("Fetching all flights");
        return flightRepository.findAll().stream()
                .map(flight -> new FlightResponse(
                        flight.getId(),
                        flight.getFlightNumber(),
                        flight.getFlightName(),
                        flight.getRoute().getOrigin(),
                        flight.getRoute().getDestination(),
                        flight.getFare(),
                        flight.getDepartureTime(),
                        flight.getArrivalTime()
                )).collect(Collectors.toList());
    }

    @Override
    public List<FlightResponse> searchFlights(FlightSearchRequest request) {
        log.info("Searching flights from {} to {} on date: {}",
                request.getOrigin(), request.getDestination(), request.getDepartureDate());

        LocalDateTime startOfDay = request.getDepartureDate().atStartOfDay();
        LocalDateTime endOfDay = request.getDepartureDate().atTime(23, 59, 59);

        List<Flight> flights = flightRepository
                .findByRoute_OriginAndRoute_DestinationAndDepartureTimeBetween(
                        request.getOrigin(), request.getDestination(),
                        startOfDay, endOfDay);

        log.info("Found {} flights for search criteria", flights.size());

        return flights.stream()
                .map(flight -> new FlightResponse(
                        flight.getId(),
                        flight.getFlightNumber(),
                        flight.getFlightName(),
                        flight.getRoute().getOrigin(),
                        flight.getRoute().getDestination(),
                        flight.getFare(),
                        flight.getDepartureTime(),
                        flight.getArrivalTime()
                )).collect(Collectors.toList());
    }
    @Override
    public FlightResponse getFlightById(Long id) {
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));

        return new FlightResponse(
                flight.getId(),
                flight.getFlightNumber(),
                flight.getFlightName(),
                flight.getRoute().getOrigin(),
                flight.getRoute().getDestination(),
                flight.getFare(),
                flight.getDepartureTime(),
                flight.getArrivalTime()
        );
    }

    @Override
    public void updateFlight(Long id, AddFlightRequest request, Authentication authentication) {
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));

        // Check if the user is the owner or admin
        String userEmail = authentication.getName();
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!user.getRole().name().equals("ADMIN") &&
            !flight.getFlightOwner().getEmail().equals(userEmail)) {
            throw new RuntimeException("Access denied to update flight");
        }

        Route route = routeRepository.findById(request.getRouteId())
                .orElseThrow(() -> new ResourceNotFoundException("Route not found"));

        flight.setFlightNumber(request.getFlightNumber());
        flight.setFlightName(request.getFlightName());
        flight.setRoute(route);
        flight.setFare(request.getFare());
        flight.setTotalSeats(request.getTotalSeats());
        flight.setBaggageCheckin(request.getBaggageCheckin());
        flight.setBaggageCabin(request.getBaggageCabin());
        flight.setDepartureTime(request.getDepartureTime());
        flight.setArrivalTime(request.getArrivalTime());

        flightRepository.save(flight);
        log.info("Flight with ID {} updated successfully", id);
    }
    @Override
    public void deleteFlight(Long id) {
        Flight flight = flightRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Flight not found"));
        flightRepository.delete(flight);
        log.info("Flight with ID {} deleted", id);
    }
}
